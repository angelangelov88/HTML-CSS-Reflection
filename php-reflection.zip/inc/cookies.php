
<div id="ac-wrapper" style='display:none'>
<div id="popup">
  <div id="cookie-text">
    <h3>Cookies Policy</h3> 
    <hr>
    <h6>We use cookies to obtain aggregate data regarding site traffic and interaction, in order to identify user trends and obtain insights in order to continually improve our site. These cookies enable us to improve your customer experience as you use our site and help provide you with relevant online marketing.
    <br><br>
    You can see a list of the other companies who use cookies on this website, by visiting cookie settings at the bottom of each page. For full details of how we use your personal information, and your rights in relation to it, view our privacy policy.
    </h6>
    <hr>
    <input type="submit" name="submit" value="Change settings" id="change-settings-btn" onClick="PopUp('hide')" />
  <input type="submit" name="submit" value="Accept Cookies" id="accept-cookies-btn" onClick="PopUp('hide')" />
  </div>
</div>
</div>
