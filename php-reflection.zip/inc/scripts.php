<!-- JQuery plugin -->
<script src="node_modules/jquery/dist/jquery.js"></script>

<!-- Owl-carousel -->
<script src="node_modules/owl.carousel/dist/owl.carousel.min.js"></script>


<!-- Main JS file -->
<script src="js/main.js"></script>
